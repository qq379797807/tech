package com.lty.wuzi3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Wuzi3Application {

	public static void main(String[] args) {
		SpringApplication.run(Wuzi3Application.class, args);
	}

}
